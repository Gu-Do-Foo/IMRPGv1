package com.example.invetariorpgv09;


public class Diversos extends Item {
    public Diversos(String nome, int valor, int quantidade, String categoria, String subcategoria, String descricao) {
        super(nome, valor, quantidade, categoria, subcategoria, descricao);
}
