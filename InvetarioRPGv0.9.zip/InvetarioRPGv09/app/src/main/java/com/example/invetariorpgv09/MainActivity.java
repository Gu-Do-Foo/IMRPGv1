package com.example.invetariorpgv09;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivityimport(androidx.appcompat.app.AppCompatActivity);

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Aqui você pode adicionar o código para interagir com as classes e implementar a lógica do seu aplicativo
    }
}

