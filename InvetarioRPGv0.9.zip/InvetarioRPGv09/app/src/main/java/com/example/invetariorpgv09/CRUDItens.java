package com.example.invetariorpgv09;
import java.util.ArrayList;
import java.util.List;

public class CrudItens {
    private List<Item> inventario;

    public CrudItens() {
        inventario = new ArrayList<>();
    }

    public void adicionarItem(Item item) {
        inventario.add(item);
    }

    public void editarItem(int indice, Item item) {
        inventario.set(indice, item);
    }

    public void removerItem(int indice) {
        inventario.remove(indice);
    }

    public void exibirItens() {
        for (Item item : inventario) {
            System.out.println(item.getNome());
        }
    }
}
    }
}

